import os
import re
import sqlite3
import io
import base64
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
import pyotp
import qrcode

app = Flask(__name__)
# In production, load this from an environment variable (e.g., os.environ.get("SECRET_KEY"))
app.secret_key = os.urandom(32)

# Secure session cookie settings
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax',
    SESSION_COOKIE_SECURE=False  # Set to True in production when using HTTPS
)

ph = PasswordHasher()
DB_NAME = "users.db"

def get_db():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                totp_secret TEXT
            )
        """)

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function

def validate_credentials(username, password):
    if not username or not re.match(r"^[a-zA-Z0-9_]{3,20}$", username):
        return "Username must be 3-20 alphanumeric characters or underscores."
    if not password or len(password) < 8 or len(password) > 128:
        return "Password must be between 8 and 128 characters."
    return None

@app.route("/")
@login_required
def dashboard():
    with get_db() as conn:
        user = conn.execute("SELECT username, totp_secret FROM users WHERE id = ?", (session["user_id"],)).fetchone()
    return render_template("dashboard.html", user=user)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        error = validate_credentials(username, password)
        if error:
            flash(error)
            return redirect(url_for("register"))

        hashed_pw = ph.hash(password)

        try:
            with get_db() as conn:
                conn.execute(
                    "INSERT INTO users (username, password_hash) VALUES (?, ?)",
                    (username, hashed_pw)
                )
            flash("Registration successful. Please log in.")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("Username already exists.")
            return redirect(url_for("register"))

    return render_template("auth.html", mode="Register")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        with get_db() as conn:
            user = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()

        if user:
            try:
                if ph.verify(user["password_hash"], password):
                    # Check if 2FA is enabled
                    if user["totp_secret"]:
                        session["pending_user_id"] = user["id"]
                        return redirect(url_for("verify_2fa"))
                    
                    session.clear()
                    session["user_id"] = user["id"]
                    return redirect(url_for("dashboard"))
            except VerifyMismatchError:
                pass

        # Generic error prevents username enumeration
        flash("Invalid username or password.")
        return redirect(url_for("login"))

    return render_template("auth.html", mode="Login")

@app.route("/2fa/setup", methods=["GET", "POST"])
@login_required
def setup_2fa():
    if request.method == "POST":
        secret = session.get("temp_totp_secret")
        code = request.form.get("code", "").strip()
        
        if secret and pyotp.TOTP(secret).verify(code):
            with get_db() as conn:
                conn.execute("UPDATE users SET totp_secret = ? WHERE id = ?", (secret, session["user_id"]))
            session.pop("temp_totp_secret", None)
            flash("2FA enabled successfully!")
            return redirect(url_for("dashboard"))
        else:
            flash("Invalid 2FA code. Try again.")

    # Generate new secret and QR code
    secret = pyotp.random_base32()
    session["temp_totp_secret"] = secret
    
    with get_db() as conn:
        user = conn.execute("SELECT username FROM users WHERE id = ?", (session["user_id"],)).fetchone()
        
    uri = pyotp.totp.TOTP(secret).provisioning_uri(name=user["username"], issuer_name="SecureApp")
    img = qrcode.make(uri)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    qr_b64 = base64.b64encode(buf.getvalue()).decode("utf-8")

    return render_template("2fa_setup.html", qr_b64=qr_b64, secret=secret)

@app.route("/2fa/verify", methods=["GET", "POST"])
def verify_2fa():
    pending_id = session.get("pending_user_id")
    if not pending_id:
        return redirect(url_for("login"))

    if request.method == "POST":
        code = request.form.get("code", "").strip()
        with get_db() as conn:
            user = conn.execute("SELECT * FROM users WHERE id = ?", (pending_id,)).fetchone()

        if user and pyotp.TOTP(user["totp_secret"]).verify(code):
            session.clear()
            session["user_id"] = user["id"]
            return redirect(url_for("dashboard"))
        
        flash("Invalid 2FA token.")

    return render_template("2fa_verify.html")

@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("You have been logged out.")
    return redirect(url_for("login"))

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
